#define _CRT_SECURE_NO_WARNINGS
//this file is dedicated to implemention of fuctions for dealing with user orders
#include "user_handler.h"

void read_word_from_user(char** word) {
	//this fuction gets a word from user for us
	//input:
		//pointer to the word in our program that is going to be taken from user
		//pointer to an int variable which holds the size of the word
	//no output
	*word = NULL;
	int word_size = 0;
	char letter = 'a';
	while (letter != ' ' && letter != '\n') {
		//getting word from user
		scanf("%c", &letter);
		word_size++;
		*word = (char*)realloc(*word, word_size);
		checking_for_null_pointer(*word);
		*(*word + word_size - 1) = letter;
	}
	*(*word + word_size - 1) = NULL; //just to make it like other strings
}

int searching_in_users(User* list_of_users, int size, char* name, int identity, int* pointer_to_index) {
	//checking if we already have an account with that username or id
	//input:
		//list of our user
		//size of the list
		//username that we're gonna search
		//id that we want to search
		//index, which indicates which user has the same username
	//output:
		//either we found that we return 1 or not that we return 0
	for (int i = 0; i < size; i++) {
		if (!strcmp((list_of_users + i)->username, name)) {
			if (identity != -1) //cause we use this function twice for different purposes
				printf("an account with that username exists\n***************************************\n");
			*pointer_to_index = i;
			return FOUND;
		}
		else if ((list_of_users + i)->id == identity) {
			printf("an account with that id exists\n***************************************\n");
			return FOUND;
		}
	}
	return NOT_FOUND;
}

int signup_user(User** pointer_to_list_of_users, int size) {
	//this fucntion will do the signup for us
	//input:
		//pointer to the main list of users
		//size, which is our user's number
	//output:
		//1 in case we successfully add new account
		//0 in case we already have that account

	char* name, * pass;										
	int identity, index;
	read_word_from_user(&name); //get username from user
	scanf("%d ", &identity); //get the id from user
	read_word_from_user(&pass); //get password from user

	if (searching_in_users(*pointer_to_list_of_users, size, name, identity, &index)) 
		//if it is already in our users
		return 0;

	//add the new account to our list in program
	*pointer_to_list_of_users = (User*)realloc(*pointer_to_list_of_users, (size + 1) * sizeof(User));
	checking_for_null_pointer(*pointer_to_list_of_users);
	(*pointer_to_list_of_users + size)->username = name;
	(*pointer_to_list_of_users + size)->password = pass;
	(*pointer_to_list_of_users + size)->id = identity;
	printf("signed up successfully\n***************************************\n");
	return 1;
}

void logging_in(User* pointer_to_list_of_users, int size, bool* pointer_to_user, bool* pointer_to_admin) {
	//this one is dedicated to logging in
	//input
		//list of users
		//size of list
		//pointer to our user mode in source code
		//pointer to our admin mode in source code 	
	//no output
	char* username, * password;
	//we first get username and password
	read_word_from_user(&username);
	read_word_from_user(&password);

	if (!strcmp(username, "admin") && !strcmp(password, "admin")) {
		//admin is here!
		printf("welcome admin\n");
		*pointer_to_admin = LOG_IN;
		free(username);
		free(password);
		return;
	}
	int index;
	if (searching_in_users(pointer_to_list_of_users, size, username, -1, &index)) {
		//now we now we have that username, we have to check the password
		if (!strcmp((pointer_to_list_of_users + index)->password, password)) {
			printf("welcom %s :)\n", username);
			*pointer_to_user = LOG_IN;	
		}
		else 
			printf("check your password again\n***************************************\n");
		free(username);
		free(password);
		return;
	}
	//if it's not admin or user
	printf("sorry, we didn't find you in our users :(\nplease check your spelling or signup first\n***************************************\n");
	free(username);
	free(password);
	return;
}

int enetring_app(User** pointer_to_list_of_users, int* size, bool* pointer_to_user, bool* pointer_to_admin){
	//this function is called when we are not signed in
	//input:
		//pointer to list of users
		//size of list
		//pointer to the users.txt file
		//pointer to our user mode in source code
		//pointer to our admin mode in source code
	//output:
		//terminate or continue

	char* order = NULL;
	read_word_from_user(&order);

	//we check the order which we were given and then do approriate jobs
	if (!strcmp(order, "terminate")) 
		return TERMINATE;
	
	if (!strcmp(order, "signup"))
		*size += signup_user(pointer_to_list_of_users, *size);
	else if (!strcmp(order, "login"))
		logging_in(*pointer_to_list_of_users, *size, pointer_to_user, pointer_to_admin);
	else if (strcmp(order, ""))
		printf("acces denied\n***************************************\n");
	free(order);
	return CONTINUE;
}

int get_order_from_user(bool* pointer_to_user) {
	//this funtion will handle users demands
	//input:
		//pinter to our user in source
	//output:
		//terminate or continue
	char* order;
	read_word_from_user(&order);
	if (!strcmp(order, "terminate")) {
		//ending our program
		free(order);
		return TERMINATE;
	}

	//now we check for different orders
	if (!strcmp(order, "logout")) {
		//we log out
		*pointer_to_user = LOG_OUT;
		printf("logged out successfully\n***************************************\n");
	}
	else if (!strcmp(order, "add_hall") || !strcmp(order, "add_food") || !strcmp(order, "add_coupon"))
		//orders that are only availabe for admin
		printf("permission denied\n***************************************\n");
	else if (!strcmp(order, "login"))
		printf("you are currently logged in\nif you want to login with another account,\nplease logout first\n***************************************\n");
	else if (strcmp(order, ""))
		printf("not valid\n***************************************\n");
	free(order);
	return CONTINUE;
}

int get_order_from_admin(Food** list_of_foods, int* foods_size, Hall** list_of_halls, int* halls_size, Coupon** list_of_coupons, int* coupons_size, bool* pointer_to_admin) {
	//this funtion will handle users demands
	//input:
		//pinter to our admin in source
		//pointer to list of foods and it's size
		//pointer to list of halls and it's size
		//pointer to list of coupons and it's size
	//output:
		//terminate or continue 
	char* order;
	read_word_from_user(&order);
	if (!strcmp(order, "terminate")) {
		//ending our program
		free(order);
		return TERMINATE;
	}

	//now we check for different orders
	if (!strcmp(order, "add_hall"))
		*halls_size += add_hall(list_of_halls, *halls_size);
	else if (!strcmp(order, "add_food"))
		*foods_size += add_food(list_of_foods, *foods_size, *list_of_halls, *halls_size);
	else if (!strcmp(order, "add_coupon"))
		*coupons_size += add_coupon(list_of_coupons, *coupons_size);
	else if (!strcmp(order, "logout")) {
		*pointer_to_admin = LOG_OUT;
		printf("logged out successfully\n***************************************\n");
	}
	else if (strcmp(order, ""))
		printf("not valid\n***************************************\n");
	free(order);
	return CONTINUE;
}

int searching_in_halls(Hall* list_of_halls, int size, int identity) {
	//this function searchs for id of halls in our list
	//input:
		//list of halls and it's size 
		//the id we are looking for
	//output:
		//found or not found
	for (int i = 0; i < size; i++) {
		if ((list_of_halls + i)->id == identity) {
			return FOUND;
		}
	}
	return NOT_FOUND;
}

int add_hall(Hall** list_of_halls, int size) {
	//this fucntion will do the adding hall for us
	//input:
		//pointer to the main list of halls
		//size, which is our halls' number
	//output:
		//1 in case we successfully add new hall
		//0 in case we already have that hall
	char* name;
	read_word_from_user(&name);
	int hall_id, capacity;
	scanf("%d %d", &hall_id, &capacity);
	if (searching_in_halls(*list_of_halls, size, hall_id)) {
		//we search for to be sure it is unique
		printf("that id for hall is not unqiue\n***************************************\n");
		return 0;
	}
	//it's unique so we add it
	*list_of_halls = (Hall*)realloc(*list_of_halls, (size + 1) * sizeof(Hall));
	checking_for_null_pointer(*list_of_halls);
	(*list_of_halls + size)->name = name;
	(*list_of_halls + size)->id = hall_id;
	(*list_of_halls + size)->capacity = capacity;
	printf("added successfully\n***************************************\n");
	return 1;
}

int add_coupon(Coupon** list_of_coupons, int size) {
	//this fucntion will do the adding coupon for us
	//input:
		//pointer to the main list of coupons
		//size, which is our coupons' number
	//output:
		//1 in case we successfully add new coupon
		//0 in case we already have that coupons id
	int identity, percentage, capacity;
	scanf("%d %d %d", &identity, &percentage, &capacity);
	if (searching_in_coupons(*list_of_coupons, size, identity)) {
		//we search for to be sure it is unique
		printf("that id for coupon is not unqiue\n***************************************\n");
		return 0;
	}
	*list_of_coupons = (Coupon*)realloc(*list_of_coupons, (size + 1) * sizeof(Coupon));
	checking_for_null_pointer(*list_of_coupons);
	(*list_of_coupons + size)->id = identity;
	(*list_of_coupons + size)->percantage = percentage;
	(*list_of_coupons + size)->capacity = capacity;
	printf("added successfully\n***************************************\n");
	return 1;
}

int add_food(Food** list_of_foods, int foods_size, Hall* list_of_halls, int halls_size) {
	//this fucntion will do the adding foods for us
	//input:
		//pointer to the main list of halls
		//size of hall
		//pointer to the main list of food
		//size of food
	//output:
		//1 in case we successfully add new food
		//0 in case we already have that food id or we dont have hall id or day is not valid 
	char* name;
	int food_id, price, capacity, hall_id, day;
	read_word_from_user(&name);
	scanf("%d %d %d %d %d", &food_id, &price, &capacity, &hall_id, &day);

	if (day > 7 || day < 1) {
		printf("day is not valid\n***************************************\n");
		return 0;
	}

	if (searching_in_halls(list_of_halls, halls_size, hall_id)) {
		//we search for the same id in halls
		if (searching_in_foods(*list_of_foods, foods_size, food_id)) {
			//we search for the food id
			printf("sorry that food id exists\n***************************************\n");
			return 0;
		}
		//hall id exists and food id is unique
		*list_of_foods = (Food*)realloc(*list_of_foods, (foods_size + 1) * sizeof(Food));
		(*list_of_foods + foods_size)->name = name;
		(*list_of_foods + foods_size)->id = food_id;
		(*list_of_foods + foods_size)->hall.id = hall_id;
		(*list_of_foods + foods_size)->capacity = capacity;
		(*list_of_foods + foods_size)->price = price;
		(*list_of_foods + foods_size)->day = day;
		printf("added successfully\n***************************************\n");
		return 1;
	}
	else {
		//if we don't have that id in our halls
		printf("sorry that hall id doesn't exists\n***************************************\n");
		return 0;
	}
}

int searching_in_foods(Food* list_of_foods, int size, int identity) {
	//this function searchs for id of foods in our list
	//input:
		//list of foods and it's size 
		//the id we are looking for
	//output:
		//found or not found
	for (int i = 0; i < size; i++) {
		if ((list_of_foods + i)->id == identity) {
			return FOUND;
		}
	}
	return NOT_FOUND;
}

int searching_in_coupons(Coupon* list_of_coupons, int size, int identity) {
	//this function searchs for id of coupons in our list
	//input:
		//list of coupons and it's size 
		//the id we are looking for
	//output:
		//found or not found
	for (int i = 0; i < size; i++) {
		if ((list_of_coupons + i)->id == identity) {
			return FOUND;
		}
	}
	return NOT_FOUND;
}